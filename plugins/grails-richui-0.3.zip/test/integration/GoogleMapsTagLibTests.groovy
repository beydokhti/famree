import de.andreasschmitt.richui.taglib.renderer.MapRenderer

class GoogleMapsTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
